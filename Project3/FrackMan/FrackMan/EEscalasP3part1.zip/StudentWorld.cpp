#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <cmath>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

StudentWorld::StudentWorld(string assetDir)
	: GameWorld(assetDir)
{
	m_frackman = new FrackMan(this);
}

/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////      I N I T      /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////

//////////////// init implementation ///////////////////////

int StudentWorld::init()		// create's current level's oil field
{
	// populates oil field with: Dirt, Boulders, Barrels of Oil, and Gold Nuggets
	
	fillOilFieldWithDirt(m_dirt);
	
	m_barrels = 2 + getLevel();
	if (m_barrels > 20) m_barrels = 20;
	addObject('O', m_barrels);

	int numBoulders = getLevel() / 2 + 2;
	if (numBoulders > 6) numBoulders = 6;
	addObject('B', numBoulders);

	int numNuggets = 5 - getLevel() / 2;
	if (numNuggets < 2) m_nuggets = 2;
	addObject('N', numNuggets);
	m_nuggets = 0;
	
	return GWSTATUS_CONTINUE_GAME;
}

////////////// function implementation /////////////////////

void StudentWorld::fillOilFieldWithDirt(Dirt* arr[][VIEW_WIDTH])
{
	// fill array with Dirt
	for (int row = 0; row < VIEW_HEIGHT; row++)
	{
		for (int col = VIEW_WIDTH - 1; col >= 0; col--)
		{
			int y = (VIEW_HEIGHT) - (row + 1);
			int x = col;

			if (x >= 30 && x <= 33 && y > 3)
				m_dirt[row][col] = nullptr;
			else if (y >= 60)
				m_dirt[row][col] = nullptr;
			else 
				m_dirt[row][col] = new Dirt(this, x, y);
		}
	}
}

void StudentWorld::removeDirtFrom(int x, int y)
{
	int row = (VIEW_HEIGHT)-(y + 1);
	int col = x;

	if (m_dirt[row][col] == nullptr)
		return;

	delete m_dirt[row][col];
	m_dirt[row][col] = nullptr;
}

bool StudentWorld::isDirtInField(int x, int y) const
{
	int row = (VIEW_HEIGHT)-(y + 1);
	int col = x;

	if (m_dirt[row][col] == nullptr)
		return false;

	return true;
}


void StudentWorld::addObject(char objectType, int numObjects)
{
	for (int k = 0; k < numObjects; k++)
	{
		int xPlacement = rand() % 61;
		int yPlacement = rand() % 61;

		if (isValidSpot(xPlacement, yPlacement))
		{
			switch (objectType)
			{
			case 'O':
				m_objects.push_back(new BarrelOfOil(m_frackman, this, xPlacement, yPlacement));
				break;
			case 'B':
				m_objects.push_back(new Boulder(this, xPlacement, yPlacement));
				for (int k = 0; k < 4; k++)
				{
					for (int j = 0; j < 4; j++)
					{
						vector<Actor*>::iterator it;
						it = m_objects.end();
						it--;
						removeDirtFrom((*it)->getX() + k, (*it)->getY() + j);
					}
				}
				break;
			case 'N':
				m_objects.push_back(new GoldNugget(m_frackman, this, xPlacement, yPlacement));
				break;
			}
		}
		else k--;
	}
}

bool StudentWorld::isValidSpot(int x, int y) const
{
	if (x >= 27 && x <= 33)
		return false;
	if (y > 56)
		return false;
	for (int k = 0; k < m_objects.size(); k++)
	{
		int objectX, objectY;
		objectX = m_objects[k]->getXValue();
		objectY = m_objects[k]->getYValue();
		double changeInX = static_cast<double>(objectX) - static_cast<double>(x);
		double changeInY = static_cast<double>(objectY) - static_cast<double>(y);
		double distance = sqrt((changeInX*changeInX) + (changeInY*changeInY));
		if (distance <= 6.0)
			return false;
	}
	return true;
}

void StudentWorld::decBarrels()
{
	m_barrels--;
}

bool StudentWorld::BoulderpointIsFree(int x, int y) const
{
	for (int k = 0; k < m_objects.size(); k++)
	{
		if (m_objects[k]->isBoulder())
		{
			int boulderX = m_objects[k]->getXValue();
			int boulderY = m_objects[k]->getYValue();
			for (int m = -2; m <= 2; m++)
			{
				for (int j = -2; j <= 2; j++)
				{
					if (boulderX + m == x && boulderY + j == y)
					{
						return false;
					}
				}
			}
		}
	}
	return true;
}

void StudentWorld::dropNugget(int x, int y)
{
	if (m_nuggets == 0) return;
	GoldNugget* nugget = new GoldNugget(m_frackman, this, x, y);
	nugget->makeVisible();
	nugget->drop();
	m_objects.push_back(nugget);
	m_nuggets--;
}

void StudentWorld::incGoldNuggets()
{
	m_nuggets++;
}
/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////      M O V E      /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////

//////////////// function implementation //////////////////////
 
string StudentWorld::setDisplayText() const
{
	int score = getScore();  // make sure is 8 digits long
	int level = getLevel();
	int lives = getLives();
	int health = 0; // FIIIIIIIIIIIIIIIIIIIIIIIIIIIIXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	int squirts = 0; //m_frackman->getGun()->getSquirts();
	int gold = m_nuggets;
	int sonar = 0;												// do later
	int barrelsLeft = m_barrels;

	return "Scr: " + to_string(score) + " Lvl: " + to_string(level) +
		" Lives: " + to_string(lives) + " Hlth: " + to_string(health) + "%" +
		" Water: " + to_string(squirts) + " Gld: " + to_string(gold) +
		" Sonar: " + to_string(sonar) + " Oil Left: " + to_string(barrelsLeft);
}

//////////////// move implementation ///////////////////////

int StudentWorld::move() // run a single tick of the game
{
	// ask game's actors to try and do something
	// deleting actors
	setGameStatText(setDisplayText());
	m_frackman->doSomething();
	for (int k = 0; k < m_objects.size(); k++)
	{
		m_objects[k]->doSomething();
		if (!m_objects[k]->isAlive())
		{
			delete m_objects[k];
			m_objects.erase(m_objects.begin() + k);
		}
	}
	removeDeadGameObjects();
	
	if (m_barrels == 0)
		return GWSTATUS_FINISHED_LEVEL;
	if (!m_frackman->isAlive())
		return GWSTATUS_PLAYER_DIED;
}


void StudentWorld::removeDeadGameObjects()
{
	for (int k = 0; k < m_objects.size(); k++)
	{
		if (!m_objects[k]->isAlive())
		{
			delete m_objects[k];
			m_objects.erase(m_objects.begin() + k);
		}

	}
}

/////////////////////////////////////////////////////////////////////////////////////////
///////////////////////     C L E A N U P     ///////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////

//////////////// function declaration //////////////////////



////////////// cleanup implementation //////////////////////

void StudentWorld::cleanUp()	// player loses a life or successfully completes a level
{
	// frees all actors
	// includes actors created in init() or modified in move()

	// delete dirt
	for (int row = 0; row < VIEW_HEIGHT; row++)
	{
		for (int col = VIEW_WIDTH - 1; col >= 0; col--)
		{
			int y = (VIEW_HEIGHT)-(row + 1);
			int x = col;

			delete m_dirt[row][col];
			m_dirt[row][col] = nullptr;
		}
	}

	// delete objects
	for (int k = 0; k < m_objects.size(); k++)
	{
		delete m_objects[k];
		m_objects[k] = nullptr;
		m_objects.erase(m_objects.begin() + k);
	}


	// delete frackman
//	delete m_frackman;
//	m_frackman = nullptr;
}

////////////// function implementation /////////////////////
